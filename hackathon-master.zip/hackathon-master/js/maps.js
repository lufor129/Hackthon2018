var map;
function initMap(LAT,LNG)
{
	var mapOptions =
	{
		center: new google.maps.LatLng(LAT,LNG),
		zoom: 14
	};
	map=new google.maps.Map(document.getElementById("map"),mapOptions);
}

function moveToLocation(LAT,LNG)
{
	var center = new google.maps.LatLng(LAT,LNG);
	map.panTo(center);
	userLocation = {lat:LAT,lng:LNG};
	var marker = new google.maps.Marker({position:userLocation,map:map});
	map.setZoom(16);
}

function getLocation()
{
	if (navigator.geolocation)
	{
		navigator.geolocation.getCurrentPosition(showPosition);
	}
	else
	{
		x.innerHTML="NOT SUPPORT.";
	}
}
 
function showPosition(position)
{
	document.getElementById("testhere").innerHTML="緯度: " + position.coords.latitude + "<br>經度: " + position.coords.longitude;
    moveToLocation(position.coords.latitude,position.coords.longitude);
}